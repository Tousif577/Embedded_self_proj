# 🎛️ Day 5 – Analog Input & ADC (Arduino Uno R4 WiFi)

This repo includes basic and advanced examples of analog input using potentiometers and sensors with Arduino Uno R4 WiFi (14-bit ADC).

## 🧪 Projects Included

### 1. Analog Potentiometer LED Brightness
Adjust LED brightness using a 10kΩ potentiometer.

### 2. Analog Fan Speed Control (Mini Project)
Control DC fan speed using PWM based on analog input.

### 3. Dual LED Control
Use two potentiometers to independently control two LEDs.

### 4. Serial Plotter ADC Monitor
Visualize analog signal in real-time using Arduino Serial Plotter.

## 🔌 Hardware
- Arduino Uno R4 WiFi
- 1 or 2 Potentiometers (10kΩ)
- 1 or 2 LEDs (or a DC fan with driver)
- 220Ω Resistors
- Breadboard, jumper wires

## 🧠 Concepts Covered
- ADC (Analog to Digital Conversion)
- Mapping ADC to PWM
- Serial monitoring and visualization
- PWM speed control of actuators

Open each `.ino` file in Arduino IDE and upload to your board.